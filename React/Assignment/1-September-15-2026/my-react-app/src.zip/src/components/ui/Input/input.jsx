import { useId } from "react";
import "./Input.css";

/*
  USAGE
  <Input
    label="Email"                          // visible label (required for accessibility)
    type="email"
    placeholder="name@example.com"
    className={inputStyles.inputOutline}   // optional variant, default = "input-default"
    helperText="We never share your email"
    error="Enter a valid email address"    // shows the error message and red border
    value={email}
    onChange={(e) => setEmail(e.target.value)}
  />
  Any other prop (disabled, required, maxLength, autoComplete...) is passed to <input>.

  For a multi-line field (a "full post", a message, an address...), add
  multiline. It renders a <textarea> instead of <input> and takes an optional
  rows (default 4). "type" is ignored when multiline is true.
    <Input label="Full post" multiline rows={6} value={fullPost} onChange={...} />
*/

function Input({
  id,
  label,
  name,
  type = "text",
  value,
  onChange,
  placeholder,
  className = "input-default",
  helperText,
  error,
  disabled,
  required,
  multiline = false,
  rows = 4,
  ...rest
}) {
  const autoId = useId();
  const inputId = id || autoId;
  const messageId = `${inputId}-message`;
  const message = error || helperText;

  return (
    <div className="input-wrapper">
      {label && (
        <label htmlFor={inputId} className="input-label">
          {label}
          {required && (
            <span className="input-required" aria-hidden="true">
              {" "}
              *
            </span>
          )}
        </label>
      )}

      {multiline ? (
        <textarea
          id={inputId}
          name={name}
          rows={rows}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          className={`input input-textarea ${className}`}
          disabled={disabled}
          required={required}
          aria-invalid={error ? "true" : undefined}
          aria-describedby={message ? messageId : undefined}
          {...rest}
        />
      ) : (
        <input
          id={inputId}
          name={name}
          type={type}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          className={`input ${className}`}
          disabled={disabled}
          required={required}
          aria-invalid={error ? "true" : undefined}
          aria-describedby={message ? messageId : undefined}
          {...rest}
        />
      )}

      {message && (
        <p
          id={messageId}
          className={
            error ? "input-message input-message-error" : "input-message"
          }
          role={error ? "alert" : undefined}
        >
          {message}
        </p>
      )}
    </div>
  );
}

export default Input;
