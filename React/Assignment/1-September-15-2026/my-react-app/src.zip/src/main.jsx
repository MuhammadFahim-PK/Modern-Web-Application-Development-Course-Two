import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navigation from "./components/ui/Navigation/navigation.jsx";
import App from "./App.jsx";

import Todos from "./pages/BlogPosts/blogposts.jsx";
import Stopwatch from "./pages/Poll/poll.jsx";

import "./index.css";

createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <Navigation />
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/poll" element={<Poll />} />
    </Routes>
  </BrowserRouter>
);
